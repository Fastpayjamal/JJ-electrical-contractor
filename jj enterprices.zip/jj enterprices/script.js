console.log("JJ Enterprices Website Loaded");
